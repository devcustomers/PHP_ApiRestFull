<?php 


class ControladorRutas{


    public function inicio(){


        include "rutas/rutas.php";



    }




}





?>